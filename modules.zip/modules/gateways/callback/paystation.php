<?php
require_once '../../../init.php';
require_once '../../../includes/gatewayfunctions.php';
require_once '../../../includes/invoicefunctions.php';

$gatewayModule = 'paystation';
$gatewayParams = getGatewayVariables($gatewayModule);

if (!$gatewayParams['type']) {
    die('Module Not Activated');
}

$data = $_GET;

// Validate callback
if (!isset($data['invoice_number']) || !isset($data['status'])) {
    logTransaction($gatewayParams['name'], $data, "Invalid Callback Data");
    die('Invalid callback data');
}

$invoiceNumber = $data['invoice_number'];
$paymentStatus = $data['status'];
$transactionId = $data['trx_id'] ?? '';
$paymentAmount = isset($data['payment_amount']) ? floatval($data['payment_amount']) : 0;

// Extract original WHMCS invoice ID
if (preg_match('/^whmcs\d{14}(\d+)$/', $invoiceNumber, $matches)) {
    $originalInvoiceId = $matches[1];
} else {
    $originalInvoiceId = $invoiceNumber;
}

// Validate invoice exists
$invoiceId = checkCbInvoiceID($originalInvoiceId, $gatewayParams['name']);

// Log transaction
logTransaction($gatewayParams['name'], $data, $paymentStatus);

// Build invoice URL
$invoiceUrl = $gatewayParams['systemurl'] . 'viewinvoice.php?id=' . $invoiceId;

// ✅ Successful payment
if ($paymentStatus === 'Successful') {
    addInvoicePayment(
        $invoiceId,
        $transactionId,
        $paymentAmount,
        0,
        $gatewayModule
    );
    header("Location: " . $invoiceUrl);
    exit;
}

// ❌ Failed or Cancelled payment
header("Location: " . $invoiceUrl);
exit;
?>