<?php
if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

/**
 * Define module metadata.
 *
 * @return array
 */
function paystation_MetaData()
{
    return [
        'DisplayName' => 'PayStation Payment Gateway',
        'APIVersion' => '1.1',
        'DisableLocalCredtCardInput' => true,
        'TokenisedStorage' => false,
        'FriendlyName' => 'PayStation Bangladesh Payment Gateway',
        'Category' => 'Payments',
        'Support' => 'https://api.paystation.com.bd/support',
        'IntegrationDeveloper' => 'PayStation Integration Team',
        'Description' => 'Integrate PayStation payment gateway for processing payments in Bangladesh. Supports both live and test modes.',
    ];
}

/**
 * Define module configuration options.
 *
 * @return array
 */
function paystation_config() {
    return [
        'FriendlyName' => [
            'Type' => 'System',
            'Value' => 'PayStation',
        ],
        'merchantId' => [
            'FriendlyName' => 'Merchant ID',
            'Type' => 'text',
            'Size' => '50',
            'Description' => 'Enter your PayStation Merchant ID',
        ],
        'password' => [
            'FriendlyName' => 'Password',
            'Type' => 'password',
            'Size' => '50',
            'Description' => 'Enter your PayStation Password',
        ],
        'apiEndpoint' => [
            'FriendlyName' => 'API Endpoint',
            'Type' => 'text',
            'Size' => '100',
            'Default' => 'https://sandbox.paystation.com.bd/initiate-payment',
            'Description' => 'Enter the PayStation API endpoint URL',
        ],
        'testMode' => [
            'FriendlyName' => 'Test Mode',
            'Type' => 'yesno',
            'Description' => 'Tick to enable test mode',
        ],
    ];
}

/**
 * Generate payment button on invoice.
 *
 * @param array $params Payment gateway parameters.
 * @return string
 */
function paystation_link($params) {
    // Gateway configuration
    $merchantId = $params['merchantId'];
    $password = $params['password'];
    $apiEndpoint = $params['apiEndpoint'];

    // Invoice details
    $invoiceId = $params['invoiceid'];
    $amount = $params['amount'];
    $currency = $params['currency'];

    // Client details
    $clientEmail = $params['clientdetails']['email'];
    $clientName = $params['clientdetails']['firstname'] . ' ' . $params['clientdetails']['lastname'];
    $clientPhone = $params['clientdetails']['phonenumber'];
    $clientAddress = $params['clientdetails']['address1'];

    // Unique invoice number for PayStation
    $datetime = date('YmdHis');
    $uniqueInvoiceId = 'whmcs' . $datetime . $invoiceId;

    // Payment data to send to API
    $paymentData = [
        'invoice_number' => $uniqueInvoiceId,
        'currency' => $currency,
        'payment_amount' => $amount,
        'pay_with_charge' => 0,
        'merchantId' => $merchantId,
        'password' => $password,
        'reference' => 'WHMCS_' . $invoiceId,
        'cust_name' => $clientName,
        'cust_phone' => $clientPhone,
        'cust_email' => $clientEmail,
        'cust_address' => $clientAddress,
        'callback_url' => rtrim($params['systemurl'], '/') . '/modules/gateways/callback/paystation.php',
        'checkout_items' => json_encode([
            'invoice_id' => $invoiceId,
            'amount' => $amount,
            'description' => 'Invoice #' . $invoiceId
        ]),
    ];

    // CURL Request to API
    $ch = curl_init($apiEndpoint);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($paymentData));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Content-Type: application/json",
        "Accept: application/json"
    ]);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
    curl_setopt($ch, CURLOPT_USERAGENT, 'WHMCS PayStation Gateway Module 1.0');

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);

    // CURL Error
    if ($curlError) {
        return "Error connecting to payment gateway: " . $curlError;
    }

    $result = json_decode($response, true);

    // HTTP Error
    if ($httpCode >= 400) {
        return "Error initiating payment: HTTP " . $httpCode;
    }

    // Parse payment URL from multiple response formats
    $paymentUrl = $result['payment_url'] ??
                  $result['data']['payment_url'] ??
                  $result['redirect_url'] ??
                  $result['url'] ??
                  $result['data']['url'] ?? null;

    // ✅ Return Pay Now button instead of redirect
    if ($paymentUrl) {
        return '<a href="' . htmlspecialchars($paymentUrl) . '" target="_blank" class="btn btn-primary">
                    <i class="fa fa-credit-card"></i> Pay Now
                </a>';
    }

    return "Error: Payment URL not received. Response: " . htmlspecialchars($response);
}